import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  ImageBackground,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { ChevronRight, Info, Download } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import { ChapterCard } from '@/components/ChapterCard';
import { SafeAreaView } from 'react-native-safe-area-context';
import { backgroundImage, capaImage, cap1Image, cap2Image, cap3Image, cap4Image, aboutImage } from '@/constants/Images';

export default function HomeScreen() {
  const router = useRouter();

  return (
    <LinearGradient
      colors={[Colors.gradientStart, Colors.gradientEnd]}
      style={styles.container}
    >
      <SafeAreaView style={styles.safeArea} edges={['bottom']}>
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          <ImageBackground 
            style={styles.header} 
            source={capaImage} 
            resizeMode="cover" 
            imageStyle={styles.headerImage}
          >
            <View style={styles.headerOverlay} />
            <View style={styles.headerContent}>
              <Text style={styles.title}>Clima Químico RA</Text>
              <Text style={styles.subtitle}>
                Explorando os compostos e reações da atmosfera terrestre
              </Text>
            </View>
          </ImageBackground>

          <View style={styles.introSection}>
            <ChapterCard
              number={0}
              title="Introdução"
              progress={0}
              backgroundImage={backgroundImage}
              showNumber={false}
              onPress={() => router.push('/introduction')}
            />
          </View>

          <TouchableOpacity onPress={() => router.push('/download')}>
            <ImageBackground
              source={backgroundImage}
              style={styles.downloadCard}
              imageStyle={styles.downloadCardImage}
              resizeMode="cover"
            >
              <View style={styles.downloadOverlay} />
              <View style={styles.downloadIconContainer}>
                <Download color={Colors.white} size={28} strokeWidth={1.8} />
              </View>
              <View style={styles.downloadTextContainer}>
                <Text style={styles.downloadTitle}>Download</Text>
                <Text style={styles.downloadSubtitle}>Livreto de marcadores RA</Text>
              </View>
              <View style={styles.downloadChevron}>
                <ChevronRight color={Colors.white} size={22} />
              </View>
            </ImageBackground>
          </TouchableOpacity>

          <Text style={styles.chaptersTitle}>Capítulos</Text>

          <ChapterCard
            number={1}
            title="Composição Atmosférica"
            description="Estudo da estrutura e composição das camadas atmosféricas."
            progress={0}
            backgroundImage={cap1Image}
            onPress={() => router.push('/chapter1')}
          />

          <ChapterCard
            number={2}
            title="Compostos Químicos e seus Impactos"
            description="Análise dos principais compostos químicos e seus efeitos."
            progress={0}
            backgroundImage={cap2Image}
            onPress={() => router.push('/chapter2')}
          />

          <ChapterCard
            number={3}
            title="Efeitos na Atmosfera"
            description="Compreensão dos impactos dos compostos nas mudanças atmosféricas."
            progress={0}
            backgroundImage={cap3Image}
            onPress={() => router.push('/chapter3')}
          />

          <ChapterCard
            number={4}
            title="Preservação e Possíveis Soluções"
            description="Estratégias para mitigar emissões e proteger o meio ambiente."
            progress={0}
            backgroundImage={cap4Image}
            onPress={() => router.push('/chapter4')}
          />

          {/* Botão Sobre */}
          <TouchableOpacity style={{ marginTop: 8 }} onPress={() => router.push('/sobre')}>
          <ImageBackground
            source={aboutImage}
            style={styles.sobreCard}
            imageStyle={styles.sobreCardImage}
            resizeMode="cover"
          >
            <View style={styles.sobreOverlay} />
            <View style={styles.sobreIconContainer}>
              <Info color={Colors.white} size={28} strokeWidth={1.8} />
            </View>
            <View style={styles.sobreTextContainer}>
              <Text style={[styles.sobreTitle, { color: Colors.white }]}>Sobre</Text>
              <Text style={[styles.sobreSubtitle, { color: 'rgba(255,255,255,0.85)' }]}>Desenvolvedores e referências</Text>
            </View>
            <View style={styles.sobreButton} >
              <ChevronRight color={Colors.white} size={22} />
            </View>
            </ImageBackground>
            </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.darkBackground,
  },

  safeArea: {
    flex: 1,
  },

  scrollContent: {
    paddingBottom: 80,
  },

  header: {
    height: 280,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 0,
    overflow: 'hidden',
  },

  headerImage: {
    overflow: 'hidden',
    width: '100%',
    borderRadius: 0,
  },

  headerOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
  },

  headerContent: {
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },

  introSection: {
    marginTop: 16,
  },

  title: {
    fontSize: 32,
    fontWeight: '900',
    color: '#FFFFFF',
    marginBottom: 8,
    textAlign: 'center',
  },

  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    fontWeight: '400',
    color: '#FFFFFF',
    lineHeight: 22,
    textAlign: 'center',
    paddingHorizontal: 16,
  },

  introContainer: {
    backgroundColor: Colors.cardBackground,
    borderRadius: 12,
    padding: 20,
    margin: 16,
    borderLeftWidth: 4,
    borderLeftColor: Colors.primary,
    shadowColor: Colors.shadowColor,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },

  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.text,
    marginBottom: 12,
    fontWeight: '600',
  },

  introText: {
    fontFamily: 'Inter-Regular',
    fontSize: 15,
    color: Colors.textSecondary,
    lineHeight: 22,
    marginBottom: 20,
  },

  startButton: {
    backgroundColor: Colors.primary,
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },

  startButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginRight: 8,
  },

  chaptersTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.text,
    marginTop: 8,
    marginBottom: 12,
    marginHorizontal: 16,
    fontWeight: '600',
  },
  sobreCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 16,
    marginHorizontal: 16,
    marginTop: 8,
    marginBottom: 8,
    padding: 18,
    overflow: 'hidden',
    gap: 14,
  },
  sobreCardImage: {
    borderRadius: 16,
  },
  sobreOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.45)',
    borderRadius: 16,
  },
  sobreIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sobreTextContainer: {
    flex: 1,
  },
  sobreTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 2,
  },
  sobreSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 13,
    color: Colors.textSecondary,
  },
  sobreButton: {
    padding: 4,
  },
  downloadCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 16,
    marginHorizontal: 16,
    marginTop: 8,
    padding: 18,
    overflow: 'hidden',
    gap: 14,
  },
  downloadCardImage: {
    borderRadius: 16,
  },
  downloadOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.55)',
    borderRadius: 16,
  },
  downloadIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  downloadTextContainer: {
    flex: 1,
  },
  downloadTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    fontWeight: '700',
    color: Colors.white,
    marginBottom: 2,
  },
  downloadSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 13,
    color: 'rgba(255,255,255,0.85)',
  },
  downloadChevron: {
    padding: 4,
  },
});